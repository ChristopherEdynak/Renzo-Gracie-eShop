// all javascript files related to themes should be require in this manifest.
$( document ).ready(function() {
  $(".table").wrap("<div class='table-responsive'></div>");
});
